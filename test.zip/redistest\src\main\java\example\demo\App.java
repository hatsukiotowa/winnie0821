package example.demo;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.Protocol;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        //JedisPool pool = new JedisPool()
        String host = "someHost"; // The primary endpoint of the cluster
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxIdle(50);
        config.setMaxTotal(100);
        config.setMaxWaitMillis(10000);

        config.setTestOnBorrow(true);
        config.setTestOnReturn(true);
        JedisPool jedisPool = new JedisPool(config, "myredis0820.redis.cache.chinacloudapi.cn", 6380, Protocol.DEFAULT_TIMEOUT,
                "git6zQgTw4TvlFpTBlDm0uAoeJ2i8Y7PD0u2TvtXJOc=", true);
        Jedis jedis = jedisPool.getResource();
        System.out.println(jedis);
    }
}
